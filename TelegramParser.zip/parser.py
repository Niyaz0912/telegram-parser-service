import asyncio
import json
from datetime import datetime
from telethon import TelegramClient
import re

CONFIG_FILE = 'config.json'

def load_config():
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def contains_real_words(text):
    """Проверяет, содержит ли текст реальные слова (а не только знаки препинания)"""
    # Убираем все знаки препинания и пробелы
    cleaned = re.sub(r'[^\w\s]', '', text)  # Убираем знаки препинания
    cleaned = cleaned.strip()  # Убираем пробелы
    
    # Проверяем остались ли буквы или цифры
    return bool(re.search(r'[a-zA-Zа-яА-ЯёЁ0-9]', cleaned))

async def main():
    config = load_config()
    
    client = TelegramClient('session_name', config['api_id'], config['api_hash'])
    await client.start()

    # 1. Запрос ссылки на чат
    chat_link = input("Введите ссылку на чат (например, t.me/telegram): ").strip()

    try:
        chat = await client.get_entity(chat_link)
        print(f"✅ Найден чат: {chat.title}")
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        await client.disconnect()
        return

    # 2. Запрос ключевых слов с ПРАВИЛЬНОЙ проверкой
    keywords = []
    while True:
        print("\n" + "=" * 50)
        keywords_input = input(
            "Введите ключевые слова для фильтрации (через запятую):\n"
            "• Пример: python, работа, 1с\n"
            "• Для выхода введите 'exit'\n"
            "> "
        ).strip()
        
        # Проверка на выход
        if keywords_input.lower() == 'exit':
            print("👋 Выход из программы.")
            await client.disconnect()
            return
        
        # Проверка на пустой ввод
        if not keywords_input:
            print("⚠️ Вы не ввели ключевые слова!")
            print("   Пожалуйста, введите слова через запятую или 'exit' для выхода.")
            continue
        
        # Разделяем по запятым и очищаем
        raw_keywords = [kw.strip() for kw in keywords_input.split(',')]
        
        # Фильтруем: оставляем только те, что содержат реальные слова
        valid_keywords = []
        invalid_keywords = []
        
        for kw in raw_keywords:
            if contains_real_words(kw):
                valid_keywords.append(kw)
            else:
                invalid_keywords.append(kw)
        
        # Если есть невалидные слова - показываем ошибку
        if invalid_keywords:
            print(f"⚠️ Эти введенные значения не содержат слов (только знаки препинания):")
            for inv_kw in invalid_keywords:
                print(f"   • '{inv_kw}'")
            print("   Пожалуйста, введите реальные слова.")
            
            # Если есть и валидные слова - спрашиваем использовать ли их
            if valid_keywords:
                use_valid = input(f"Использовать только валидные слова ({', '.join(valid_keywords)})? (да/нет): ").strip().lower()
                if use_valid in ['да', 'yes', 'y', 'д']:
                    keywords = valid_keywords
                    print(f"🔍 Используются ключевые слова: {keywords}")
                    break
            continue
        
        # Если все слова валидны
        if valid_keywords:
            keywords = valid_keywords
            print(f"✅ Ключевые слова приняты: {keywords}")
            break
        else:
            print("⚠️ Вы ввели только знаки препинания и пробелы.")
            print("   Пожалуйста, введите реальные слова (буквы или цифры).")

    # 3. Собираем и фильтруем сообщения
    print(f"\n⏳ Собираю сообщения из чата '{chat.title}'...")
    all_messages = []
    found_count = 0
    
    async for message in client.iter_messages(chat, limit=config.get('limit_messages', 1000)):
        message_text = message.text or ''
        message_date = message.date.strftime("%Y-%m-%d %H:%M:%S")
        sender_id = str(message.sender_id) if message.sender_id else "Unknown"
        
        # Получаем имя отправителя если возможно
        sender_name = "Unknown"
        try:
            if message.sender:
                sender_name = getattr(message.sender, 'first_name', '') or getattr(message.sender, 'username', '') or getattr(message.sender, 'title', '')
                if not sender_name:
                    sender_name = str(message.sender_id)
        except:
            sender_name = str(sender_id)
        
        # Проверяем фильтрацию
        should_add = True
        if keywords:
            text_lower = message_text.lower()
            # Ищем хотя бы одно ключевое слово
            if not any(kw.lower() in text_lower for kw in keywords):
                should_add = False
        
        if should_add:
            all_messages.append({
                'date': message_date,
                'sender_id': sender_id,
                'sender_name': sender_name,
                'text': message_text,
                'message_id': message.id
            })
            found_count += 1

    # 4. Сохраняем в красивый текстовый файл
    if all_messages:
        output_file = f'messages_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'
        
        with open(output_file, 'w', encoding='utf-8') as f:
            # Заголовок
            f.write("=" * 80 + "\n")
            f.write(f"📊 РЕЗУЛЬТАТЫ ПАРСИНГА TELEGRAM ЧАТА\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"📌 Информация о парсинге:\n")
            f.write(f"   Чат: {chat.title}\n")
            f.write(f"   Время парсинга: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"   Найдено сообщений: {found_count}\n")
            
            if keywords:
                f.write(f"   Ключевые слова: {', '.join(keywords)}\n")
            else:
                f.write(f"   Фильтрация: НЕТ (все сообщения)\n")
            
            f.write("\n" + "=" * 80 + "\n\n")
            
            # Сообщения
            for i, msg in enumerate(all_messages, 1):
                f.write(f"📝 СООБЩЕНИЕ #{i}\n")
                f.write(f"   {'─' * 40}\n")
                f.write(f"   📅 Дата: {msg['date']}\n")
                f.write(f"   👤 Отправитель: {msg['sender_name']} (ID: {msg['sender_id']})\n")
                f.write(f"   🔗 ID сообщения: {msg['message_id']}\n")
                f.write(f"   {'─' * 40}\n")
                f.write(f"   Текст:\n")
                
                # Форматируем текст с отступами
                text_lines = msg['text'].split('\n')
                for line in text_lines:
                    if line.strip():  # Не добавляем пустые строки
                        f.write(f"   │ {line}\n")
                    else:
                        f.write(f"   │\n")
                
                f.write(f"   {'─' * 40}\n\n")
                
                # Добавляем разделитель каждые 5 сообщений для читабельности
                if i % 5 == 0 and i < len(all_messages):
                    f.write(f"📄 Страница {i//5}\n")
                    f.write("=" * 80 + "\n\n")
        
        print(f"\n✅ Готово! Сохранено {found_count} сообщений")
        print(f"📁 Файл: {output_file}")
        
        if keywords:
            print(f"🔍 Использованы ключевые слова: {keywords}")
        else:
            print(f"🔍 Режим: все сообщения (без фильтрации)")
        
        # Выводим краткую статистику
        print(f"\n📊 Статистика:")
        print(f"   • Сообщений сохранено: {found_count}")
        print(f"   • Дата первого сообщения: {all_messages[-1]['date'] if all_messages else 'N/A'}")
        print(f"   • Дата последнего сообщения: {all_messages[0]['date'] if all_messages else 'N/A'}")
        
    else:
        print(f"\n❌ Сообщений не найдено")
        if keywords:
            print(f"🔍 Ключевые слова: {keywords}")
        else:
            print(f"ℹ️ Чат пуст или произошла ошибка")

    await client.disconnect()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Программа прервана пользователем.")
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")