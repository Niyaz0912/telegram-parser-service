import asyncio
import json
import csv
from telethon import TelegramClient

CONFIG_FILE = 'config.json'

def load_config():
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

async def main():
    config = load_config()
    
    client = TelegramClient('session_name', config['api_id'], config['api_hash'])
    await client.start()

    # 1. Запрос ссылки на чат
    chat_link = input("Введите ссылку на чат (например, t.me/telegram): ").strip()

    try:
        chat = await client.get_entity(chat_link)
        print(f"Найден чат: {chat.title}")
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        await client.disconnect()
        return

    # 2. Собираем сообщения
    all_messages = []
    async for message in client.iter_messages(chat, limit=config.get('limit_messages', 500)):
        all_messages.append({
            'date': message.date,
            'sender_id': message.sender_id,
            'text': message.text or ''
        })

    # 3. Запрос ключевых слов для фильтрации
    keywords_input = input("Введите ключевые слова для фильтрации (через запятую): ").strip()
    if keywords_input:
        keywords = [kw.strip() for kw in keywords_input.split(',')]
    else:
        keywords = config.get('keywords', [])
    
    print(f"🔍 Ключевые слова для поиска: {keywords}")
    
    # 4. Фильтрация
    if keywords:
        filtered_messages = []
        for msg in all_messages:
            text_lower = msg['text'].lower()
            if any(kw.lower() in text_lower for kw in keywords):
                filtered_messages.append(msg)
    else:
        filtered_messages = all_messages

    # 5. Сохраняем в CSV
    if filtered_messages:
        with open('messages.csv', 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=['date', 'sender_id', 'text'])
            writer.writeheader()
            writer.writerows(filtered_messages)
        print(f"✅ Готово! Сохранено {len(filtered_messages)} сообщений в файл 'messages.csv'")
        if keywords:
            print(f"🔍 Использованы ключевые слова: {keywords}")
    else:
        print("ℹ️ В чате не найдено сообщений (или ни одно не подошло под фильтр).")

    await client.disconnect()

if __name__ == '__main__':
    asyncio.run(main())