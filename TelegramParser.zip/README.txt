# Telegram Parser

1. Получите api_id и api_hash на https://my.telegram.org
2. Установите Python 3.8+ и зависимости: pip install -r requirements.txt
3. Скопируйте config.example.json в config.json и настройте
4. Запустите: python parser.py

Поддержка: https://t.me/ваш_контакт